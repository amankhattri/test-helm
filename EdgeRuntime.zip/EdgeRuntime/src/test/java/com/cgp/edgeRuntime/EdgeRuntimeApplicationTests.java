package com.cgp.edgeRuntime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdgeRuntimeApplicationTests {

	@Test
	void contextLoads() {
	}

}
