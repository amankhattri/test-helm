package com.cgp.serviceBus;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.azure.messaging.servicebus.ServiceBusReceivedMessage;
import com.cgp.kubernetes.KubernetesMain;
import com.cgp.models.HelmDeploymentDetail;
import com.cgp.models.Message;
import com.cgp.models.PodStatus;
import com.google.gson.Gson;

@Component
public class MessageHandler {

	@Autowired
	AzureComms comms;

	@Autowired
	KubernetesMain kubernetes;

	public void processMessage(ServiceBusReceivedMessage message) {
		Message responseMsg = message.getBody().toObject(Message.class);
		System.out.println(responseMsg.toString());
		String type = responseMsg.getType();
		switch (type) {
		case "DeploymentReq":
			// comms.sendMsg(HandleDeploymentRequest(responseMsg));
			// HandleDeploymentRequest(responseMsg);
			CompletableFuture.supplyAsync(() -> HandleDeploymentRequest(responseMsg))
					.thenAccept(msg -> comms.sendMsg(msg));

			break;
		default:
			System.out.println("in default");// responseMsg.toString());

		}
	//	System.out.println("processed message");
	}

	public Message HandleDeploymentRequest(Message responseMsg) {

		Gson gson = new Gson();

		HelmDeploymentDetail helm_detail = gson.fromJson(responseMsg.getPayload().toString(),
				HelmDeploymentDetail.class);
		Message m = new Message();
		Map<String,Object> response = kubernetes.execute(helm_detail);
	    String status  =(String) response.get("STATUS");	
	    
		if (status.equals("SUCCESS")) {
		
		
			//List<PodStatus> pods = new ArrayList<>();
			//response.get("data")
			m.setPayload( gson.toJson(response.get("data")));
			m.setStatus("SUCCESS");
		} else if(status.equals("FAILURE")){
			m.setPayload("not deployed");
			m.setStatus("Failure");

		}

		m.setId(responseMsg.getId());
		m.setType("DeploymentRes");
		// comms.sendMsg(m);
		System.out.println("in handle deployment response " +m.toString());
		return m;
	}

}
