package com.cgp.serviceBus;

import com.cgp.models.Message;

public interface AzureComms {

	String configureSender(String name, String entityType,String endpoints);

	String configureReceiver(String name, String entityType,String endpoints);

	String configureReceiver(String name, String entityType,String endpoints, String subscription);

	String sendMsg(Message data);

	String receiveMsg();

}