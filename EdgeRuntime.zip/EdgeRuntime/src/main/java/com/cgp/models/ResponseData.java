package com.cgp.models;

import java.util.List;

public class ResponseData {

	private DeviceDetails device;
	private List<NamespaceDetails> Mngment;
	private List<NamespaceDetails> Service;

	public DeviceDetails getDevice() {
		return device;
	}

	public void setDevice(DeviceDetails device) {
		this.device = device;
	}

	public List<NamespaceDetails> getMngment() {
		return Mngment;
	}

	public void setMngment(List<NamespaceDetails> mngment) {
		Mngment = mngment;
	}

	public List<NamespaceDetails> getService() {
		return Service;
	}

	public void setService(List<NamespaceDetails> service) {
		Service = service;
	}

}
