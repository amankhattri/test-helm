package com.cgp.models;

import java.io.Serializable;
import java.util.Map;

public class HelmDeploymentDetail implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String helmId;
	private String chartName;
	private String chartRepoName;
	private String chartRepoUrl;
	private Map<String,String> extraParameters;

	public String getHelmId() {
		return helmId;
	}

	public void setHelmId(String helmId) {
		this.helmId = helmId;
	}

	public String getChartName() {
		return chartName;
	}

	public void setChartName(String chartName) {
		this.chartName = chartName;
	}

	public String getChartRepoName() {
		return chartRepoName;
	}

	public void setChartRepoName(String chartRepoName) {
		this.chartRepoName = chartRepoName;
	}

	public String getChartRepoUrl() {
		return chartRepoUrl;
	}

	public void setChartRepoUrl(String chartRepoUrl) {
		this.chartRepoUrl = chartRepoUrl;
	}

	public Map<String,String> getExtraParameters() {
		return extraParameters;
	}

	public void setExtraParameters(Map<String,String> extraParameters) {
		this.extraParameters = extraParameters;
	}

}
