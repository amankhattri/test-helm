package com.cgp.models;

import java.util.Map;

public class DeploymentDetails {

	private String helmId;
	private Map<String, PodStatus> podDetails;
	private Map<String, FtegServiceDetails> svcDetails;

	public String getHelmId() {
		return helmId;
	}

	public void setHelmId(String helmId) {
		this.helmId = helmId;
	}

	public Map<String, PodStatus> getPodDetails() {
		return podDetails;
	}

	public void setPodDetails(Map<String, PodStatus> podDetails) {
		this.podDetails = podDetails;
	}

	public Map<String, FtegServiceDetails> getSvcDetails() {
		return svcDetails;
	}

	public void setSvcDetails(Map<String, FtegServiceDetails> svcDetails) {
		this.svcDetails = svcDetails;
	}

}
