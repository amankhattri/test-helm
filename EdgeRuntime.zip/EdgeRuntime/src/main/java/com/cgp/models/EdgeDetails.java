package com.cgp.models;

import java.util.List;

public class EdgeDetails {

	private String edge_id;

	private String name;
	private String location;

	private String status;

	private List<PodStatus> poddetails;

	private String hostip;

	public EdgeDetails() {
	}

	public EdgeDetails(String name, String location) {
		super();
		this.name = name;
		this.location = location;
	}

	public String getEdge_id() {
		return edge_id;
	}

	public void setEdge_id(String edge_id) {
		this.edge_id = edge_id;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getEdge_name() {
		return name;
	}

	public void setEdge_name(String edge_name) {
		this.name = edge_name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<PodStatus> getPoddetails() {
		return poddetails;
	}

	public void setPoddetails(List<PodStatus> poddetails) {
		this.poddetails = poddetails;
	}

	public String getHostip() {
		return hostip;
	}

	public void setHostip(String hostip) {
		this.hostip = hostip;
	}

}
