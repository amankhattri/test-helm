package com.cgp.models;

import java.util.List;

public class FtegServiceDetails {

	private String clusterIp;
	private List<String> Ports;	
	private String publicIP;
	public String getClusterIp() {
		return clusterIp;
	}
	public void setClusterIp(String clusterIp) {
		this.clusterIp = clusterIp;
	}
	public List<String> getPorts() {
		return Ports;
	}
	public void setPorts(List<String> ports) {
		Ports = ports;
	}
	public String getPublicIP() {
		return publicIP;
	}
	public void setPublicIP(String publicIP) {
		this.publicIP = publicIP;
	}

}
