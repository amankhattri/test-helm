package com.cgp.models;


public class NamespaceDetails {

 
    private String name;
    private String type;
    private String endpoint;
    private String mtype;
    

    private String subsriptionName;
    
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getEndpoint() {
		return endpoint;
	}
	public void setEndpoint(String endpoint) {
		this.endpoint = endpoint;
	}
	public String getMtype() {
		return mtype;
	}
	public void setMtype(String mtype) {
		this.mtype = mtype;
	}
	public String getSubsriptionName() {
		return subsriptionName;
	}

	
    
	
}
