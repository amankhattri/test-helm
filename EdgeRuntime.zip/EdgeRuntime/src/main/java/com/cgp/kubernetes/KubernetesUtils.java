package com.cgp.kubernetes;

import java.io.IOException;

import org.springframework.stereotype.Component;

import io.kubernetes.client.openapi.ApiClient;
import io.kubernetes.client.openapi.Configuration;
import io.kubernetes.client.openapi.apis.CoreV1Api;
import io.kubernetes.client.util.Config;

@Component
public class KubernetesUtils {

	private ApiClient connectionclient;
    private CoreV1Api api;


	public KubernetesUtils() {
		try {
			//connectionclient = Config.fromConfig("/Users/amankhattri/Documents/sts/config");
			connectionclient = Config.defaultClient();
			Configuration.setDefaultApiClient(connectionclient);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		api = new CoreV1Api();
	}

	public CoreV1Api getApi() {
		return api;
	}

	public ApiClient getConnectionclient() {
		return connectionclient;
	}
}
