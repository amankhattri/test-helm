package com.cgp.kubernetes;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cgp.models.HelmDeploymentDetail;
import com.cgp.models.PodStatus;
import com.google.gson.reflect.TypeToken;

import io.kubernetes.client.openapi.ApiException;
import io.kubernetes.client.openapi.models.V1ContainerStateWaiting;
import io.kubernetes.client.openapi.models.V1ContainerStatus;
import io.kubernetes.client.openapi.models.V1DeploymentList;
import io.kubernetes.client.openapi.models.V1Pod;
import io.kubernetes.client.openapi.models.V1PodIP;
import io.kubernetes.client.openapi.models.V1PodList;
import io.kubernetes.client.util.Watch;
import io.kubernetes.client.util.Watch.Response;

@Component
public class KubernetesMain {
	@Autowired
	KubernetesUtils utils;

	Process p = null;
	HelmDeploymentDetail helm_detail;
	Map<String, PodStatus> podMap;
	String helm = "helm";
	

	public Map<String,Object> execute(HelmDeploymentDetail helm_detail) {

        Map<String,Object> response = new HashMap<>();		
		boolean status = true;
		this.helm_detail = helm_detail;
		// add Repo
		helmRepoAdd();
		// install helm_chart
		if (!helmInstall()) {
			//return false;
			response.put("STATUS", "FAILURE");
			return response;

		}
		// check container status
		Map<String, String> label = new HashMap<String, String>();
		label.put("release", helm_detail.getHelmId());
		checkDeploymentStatus(label);

		for (PodStatus pod : podMap.values()) {
			if (!pod.getStatus().equals("Running")) {
				status = false;
				response.put("STATUS", "FAILURE");
				helmRollback();
				return response;
			}
		}

		
		fillPodData(label);
        response.put("STATUS", "SUCCESS");
		response.put("data", podMap);
		//return status;
		return response;

	}

	private void fillPodData(Map<String, String> label) {
		String labelstr = label.toString().replaceAll("^.|.$", "");

	try {
		
		 V1PodList podlist= utils.getApi().listPodForAllNamespaces(null, null, null, labelstr, null, null, null, null, null, null);
		 
		 for(V1Pod depolyed_pod : podlist.getItems())
		 {
			 
		    if(podMap.containsKey(depolyed_pod.getMetadata().getName()))
		    {
		    	
		    	PodStatus status = podMap.get(depolyed_pod.getMetadata().getName());
		        List<V1PodIP> podIps = depolyed_pod.getStatus().getPodIPs();
		         for(V1PodIP ip : podIps )
		         {
		        	 status.getPodIP().add(ip.getIp());
		         }
		    			
		    	
		  //  	depolyed_pod.getSpec().getContainers().
		    }
			 
		 }
		
	} catch (ApiException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	}

	private boolean helmInstall() {

		String helmId = helm_detail.getHelmId();
		String helmChart = helm_detail.getChartName();
		String setParams = " ";
		if (helm_detail.getExtraParameters() != null && !helm_detail.getExtraParameters().isEmpty()) {
			Map<String, String> extraParameter = helm_detail.getExtraParameters();
			setParams = setParams.concat(extraParameter.toString().replaceAll("^.|.$", ""));
		}

		String command =  helm +" install " + helmId + "  " + helmChart + setParams;
		try {
			return processExecute(command);

		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;

	}

	private void helmRepoAdd() {
		String repository = helm_detail.getChartRepoUrl();
		String repoName = helm_detail.getChartRepoName();
		String command = helm +" repo add " + repoName + " " + repository;
		try {
			processExecute(command);

		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void checkDeploymentStatus(Map<String, String> label) {
		try {
			podMap = new HashMap<String, PodStatus>();
			String labelstr = label.toString().replaceAll("^.|.$", "");
			// String status;

			Watch<V1Pod> watch = Watch
					.createWatch(
							utils.getConnectionclient(), utils.getApi().listPodForAllNamespacesCall(null, null, null,
									labelstr, null, null, null, null, 60, Boolean.TRUE, null),
							new TypeToken<Watch.Response<V1Pod>>() {
							}.getType());

			for (Response<V1Pod> event : watch) {
				V1Pod pod = event.object;
				// System.out.println(" watch ::" + event.type);
				PodStatus podStatus = new PodStatus();
				podStatus.setName(pod.getMetadata().getName());
				podStatus.setStatus(pod.getStatus().getPhase());
				// System.out.println(pod.getMetadata().getName());
				System.out.println(pod.getStatus().getPhase());

				List<V1ContainerStatus> status = pod.getStatus().getContainerStatuses();
				if (status != null) {
					for (V1ContainerStatus state : status) {
						V1ContainerStateWaiting container_state = state.getState().getWaiting();
						if (container_state != null)
							podStatus.setMessage(container_state.getReason());
						// System.out.println(container_state.getReason());

					}
				}
				podMap.put(podStatus.getName(), podStatus);
			}

		} catch (ApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private boolean helmRollback() {

		String command = helm+" del " + helm_detail.getHelmId();
		try {
			return processExecute(command);

		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;

	}

	private boolean processExecute(String cmd) throws IOException, InterruptedException {

		p = Runtime.getRuntime().exec(cmd);
		p.waitFor();
		InputStream is;
		int status = p.exitValue();
		if (status == 0)
			is = p.getInputStream();
		else
			is = p.getErrorStream();
		BufferedReader input = new BufferedReader(new InputStreamReader(is));

		String line = null;

		while ((line = input.readLine()) != null) {
			System.out.println(line);
		}
		return status == 0 ? true : false;
	}

}
