package com.cgp.kubernetes;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cgp.models.DeploymentDetails;
import com.cgp.models.FtegServiceDetails;
import com.cgp.models.HelmDeploymentDetail;
import com.cgp.models.PodStatus;
import com.google.gson.reflect.TypeToken;

import io.kubernetes.client.openapi.ApiException;
import io.kubernetes.client.openapi.models.V1ContainerStateWaiting;
import io.kubernetes.client.openapi.models.V1ContainerStatus;
import io.kubernetes.client.openapi.models.V1Pod;
import io.kubernetes.client.openapi.models.V1PodIP;
import io.kubernetes.client.openapi.models.V1PodList;
import io.kubernetes.client.openapi.models.V1Service;
import io.kubernetes.client.openapi.models.V1ServiceList;
import io.kubernetes.client.openapi.models.V1ServicePort;
import io.kubernetes.client.util.Watch;
import io.kubernetes.client.util.Watch.Response;

@Component
public class KubernetesMain {
	@Autowired
	KubernetesUtils utils;

	@Autowired
	DeploymentDetails deploymentDetails;

	Process p = null;
	HelmDeploymentDetail helm_detail;
	Map<String, PodStatus> podMap;
	Map<String, FtegServiceDetails> svcMap;

	String helm = "helm";

	Logger logger = LoggerFactory.getLogger(KubernetesMain.class);

	public Map<String, Object> execute(HelmDeploymentDetail helm_detail) {

		Map<String, Object> response = new HashMap<>();
		// boolean status = true;
		this.helm_detail = helm_detail;
		// add Repo
		if (!helm_detail.getHelm_origins().equalsIgnoreCase("local")) {
			logger.info("remote helm deployment .. ");
			helmRepoAdd();
		} else {
			logger.info("local helm deployment .. ");
		}
		// install helm_chart
		if (!helmInstall()) {
			// return false;
			response.put("STATUS", "FAILURE");
			return response;

		}
		// check container status
		Map<String, String> label = new HashMap<String, String>();
		// label.put("release", helm_detail.getHelmId());
		label.put("app.kubernetes.io/instance", helm_detail.getHelmId());
		checkDeploymentStatus(label);

		for (PodStatus pod : podMap.values()) {
			if (!pod.getStatus().equals("Running")) {
				// status = false;
				response.put("STATUS", "FAILURE");
				helmRollback();
				return response;
			}
		}

		fillDeploymentData(label);
		response.put("STATUS", "SUCCESS");
		response.put("data", podMap);
		// return status;
		return response;

	}

	public Map<String, Object> executeForDeletion(HelmDeploymentDetail helm_detail) {

		Map<String, Object> response = new HashMap<>();
		this.helm_detail = helm_detail;
		if (helmRollback())
			response.put("STATUS", "SUCCESS");
		else
			response.put("STATUS", "FAILURE");
		// return status;
		return response;

	}

	private void fillDeploymentData(Map<String, String> label) {
		String labelstr = label.toString().replaceAll("^.|.$", "");

		try {

			V1PodList podlist = utils.getApi().listPodForAllNamespaces(null, null, null, labelstr, null, null, null,
					null, null, null);

			for (V1Pod depolyed_pod : podlist.getItems()) {

				if (podMap.containsKey(depolyed_pod.getMetadata().getName())) {

					PodStatus status = podMap.get(depolyed_pod.getMetadata().getName());
					List<V1PodIP> podIps = depolyed_pod.getStatus().getPodIPs();
					for (V1PodIP ip : podIps) {
						status.getPodIP().add(ip.getIp());
					}

					// depolyed_pod.getSpec().getContainers().
				}

			}

			V1ServiceList svc_list = utils.getApi().listServiceForAllNamespaces(null, null, null, labelstr, null, null,
					null, null, null, null);

			svcMap = new HashMap<>();

			for (V1Service svc : svc_list.getItems()) {
				System.out.println(svc.getSpec().getSelector());

				if (svc.getSpec().getSelector() != null && svc.getSpec().getSelector().containsKey("app")
						&& svc.getSpec().getSelector().get("app").equals("fteg"))

				{
					FtegServiceDetails fteg = new FtegServiceDetails();
					fteg.setClusterIp(svc.getSpec().getClusterIP());
					List<String> ftegPorts = new ArrayList<>();
					List<V1ServicePort> ports = svc.getSpec().getPorts();
					for (V1ServicePort port : ports) {
						ftegPorts.add(port.getPort().toString());
					}
					fteg.setPorts(ftegPorts);

					svcMap.put("fteg", fteg);
					// System.out.println(svc.getSpec().getClusterIP() +
					// svc.getSpec().getPorts().get(0).getPort());
				}

				if (svc.getSpec().getSelector() != null && svc.getSpec().getSelector().containsKey("app")
						&& svc.getSpec().getSelector().get("app").equals("fteg-ct"))

				{
					FtegServiceDetails fteg_ct = new FtegServiceDetails();
					fteg_ct.setClusterIp(svc.getSpec().getClusterIP());
					List<String> fteg_ctPorts = new ArrayList<>();
					List<V1ServicePort> ports = svc.getSpec().getPorts();
					for (V1ServicePort port : ports) {
						fteg_ctPorts.add(port.getPort().toString());
					}
					fteg_ct.setPorts(fteg_ctPorts);
					svcMap.put("fteg-ct", fteg_ct);

					// System.out.println(svc.getSpec().getClusterIP() +
					// svc.getSpec().getPorts().get(0).getPort());
				}

			}

			deploymentDetails.setHelmId(this.helm_detail.getHelmId());
			deploymentDetails.setPodDetails(podMap);
			deploymentDetails.setSvcDetails(svcMap);

		} catch (ApiException e) {
			// TODO Auto-generated catch block
			logger.error("error in fill deployment details : " + e.getMessage());
			// e.printStackTrace();
		} catch (Exception e) {
			logger.error("error in fill deployment details : " + e.getMessage());

		}

	}

	private boolean helmInstall() {

		String helmId = helm_detail.getHelmId();
		String helmChart = helm_detail.getChartName();
		String setParams = "  --set ";
		if (helm_detail.getExtraParameters() != null && !helm_detail.getExtraParameters().isEmpty()) {
			Map<String, String> extraParameter = helm_detail.getExtraParameters();
			setParams = setParams.concat(extraParameter.toString().replaceAll("^.|.$", ""));
		}

		String command = helm + " install " + helmId + "  " + helmChart + setParams;
		logger.info("helm cmd : " + command);
		try {
			return processExecute(command);

		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			logger.error("error in helm install  : " + e.getMessage());
		}
		return false;

	}

	private void helmRepoAdd() {
		String repository = helm_detail.getChartRepoUrl();
		String repoName = helm_detail.getChartRepoName();
		String command = helm + " repo add " + repoName + " " + repository;
		logger.info("helm cmd : " + command);

		try {
			processExecute(command);

		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			logger.error("error in helmRepo add  : " + e.getMessage());
		}

	}

	private void checkDeploymentStatus(Map<String, String> label) {
		logger.info("in checkDeployment Status");
		try {
			podMap = new HashMap<String, PodStatus>();
			String labelstr = label.toString().replaceAll("^.|.$", "");
			// String status;

			Watch<V1Pod> watch = Watch
					.createWatch(
							utils.getConnectionclient(), utils.getApi().listPodForAllNamespacesCall(null, null, null,
									labelstr, null, null, null, null, 30, Boolean.TRUE, null),
							new TypeToken<Watch.Response<V1Pod>>() {
							}.getType());

			for (Response<V1Pod> event : watch) {
				V1Pod pod = event.object;
				// System.out.println(" watch ::" + event.type);
				PodStatus podStatus = new PodStatus();
				podStatus.setName(pod.getMetadata().getName());
				podStatus.setStatus(pod.getStatus().getPhase());
				// System.out.println(pod.getMetadata().getName());
				logger.info(pod.getStatus().getPhase());

				List<V1ContainerStatus> status = pod.getStatus().getContainerStatuses();
				if (status != null) {
					for (V1ContainerStatus state : status) {
						V1ContainerStateWaiting container_state = state.getState().getWaiting();
						if (container_state != null)
							podStatus.setMessage(container_state.getReason());
						// System.out.println(container_state.getReason());

					}
				}
				podMap.put(podStatus.getName(), podStatus);
			}

		} catch (ApiException e) {
			// TODO Auto-generated catch block
			logger.error("error in checkDeploymentStatus  : " + e.getMessage());
		} catch (Exception e) {
			logger.error("error in checkDeploymentStatus  : " + e.getMessage());
		}
	}

	private boolean helmRollback() {

		String command = helm + " del " + helm_detail.getHelmId();
		logger.info("helm cmd : " + command);

		try {
			boolean status = false;
			status = processExecute(command);
			deploymentDetails.setHelmId("");
			deploymentDetails.setPodDetails(null);
			deploymentDetails.setSvcDetails(null);
			return status;
		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			logger.error("error in helm roll back  : " + e.getMessage());

		}
		return false;

	}

	private boolean processExecute(String cmd) throws IOException, InterruptedException {
		logger.info(" in process execute ..");
		p = Runtime.getRuntime().exec(cmd);
		p.waitFor();
		InputStream is;
		int status = p.exitValue();
		if (status == 0)
			is = p.getInputStream();
		else
			is = p.getErrorStream();
		BufferedReader input = new BufferedReader(new InputStreamReader(is));

		String line = null;

		while ((line = input.readLine()) != null) {
			logger.info(line);
		}
		logger.info("process status : " + status);
		return status == 0 ? true : false;
	}

}
