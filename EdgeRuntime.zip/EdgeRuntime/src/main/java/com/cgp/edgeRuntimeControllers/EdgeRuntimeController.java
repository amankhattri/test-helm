package com.cgp.edgeRuntimeControllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cgp.models.DeploymentDetails;
import com.cgp.models.FtegServiceDetails;
import com.cgp.models.ResponseData;

@RestController
public class EdgeRuntimeController {

	@Autowired
	ResponseData responseData;
	
	@Autowired
	DeploymentDetails deploymentDetails;
	
	Logger logger =  LoggerFactory.getLogger(EdgeRuntimeController.class);

	
	@GetMapping("/namespaceInfo/{mType}")
	public ResponseEntity<?> getNamespaceInfo(@PathVariable String mType) {
		return new ResponseEntity<>(responseData.getService(), HttpStatus.OK);
	}
 
	
	@GetMapping("/ftegSvcDetails")
	public ResponseEntity<?> ftegSvcDetails() {	
		
		if (deploymentDetails.getSvcDetails() != null) {
			FtegServiceDetails ftegServiceDetails = deploymentDetails.getSvcDetails().get("fteg");
			logger.info("Fteg service details: "+ ftegServiceDetails.getClusterIp() +":"+ ftegServiceDetails.getPorts().get(0));
			return new ResponseEntity<>(ftegServiceDetails, HttpStatus.OK);

		}
		
		else {
			logger.error("Fteg service details not found.. " );
			return new ResponseEntity<>("ERROR", HttpStatus.OK);
		}

	}
}
