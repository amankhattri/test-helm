package com.cgp.edgeRuntime;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cgp.models.ResponseData;
import com.cgp.serviceBus.AzureComms;
import com.cgp.serviceBus.AzureCommsImpl;

@Configuration
public class EdgeRuntimeConfiguration {

	@Bean
	public AzureComms azureComms() {
		System.out.println("in azure comms");
		AzureComms comms = new AzureCommsImpl();

		return comms;
	}

	@Bean
	public ResponseData responseData() {
		return new ResponseData();
	}
}
