package com.cgp.edgeRuntime;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.cgp.ertServices.ErtServices;
import com.cgp.models.DeviceDetails;
import com.cgp.models.NamespaceDetails;
import com.cgp.models.ResponseData;
import com.cgp.serviceBus.AzureComms;

@Component
public class ErtRun implements CommandLineRunner {

	@Autowired
	ErtServices svc;

	@Autowired
	AzureComms comms;

	@Autowired
	ResponseData responseData;

	@Value("${device.name}")
	private String deviceName;

	@Value("${device.location}")
	private String deviceLocation;

	private String hostip_key ="HOST_IP";
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub

		// Register Device object
		DeviceDetails detail = new DeviceDetails(deviceName, deviceLocation);
		detail.setHostip(System.getenv(hostip_key));
		ResponseData response = svc.DeviceRegistration(detail);
		responseData.setDevice(response.getDevice());
		responseData.setMngment(response.getMngment());
		responseData.setService(response.getService());
		detail = responseData.getDevice();
		System.out.println("device registered with id" + detail.getDevice_id());

		// Get Subscription
		List<NamespaceDetails> mngmt_namespace = null;
		mngmt_namespace = responseData.getMngment();
		// configure azure comms object
		if (mngmt_namespace != null) {
			for (NamespaceDetails namespace : mngmt_namespace) {
				if (namespace.getType().equals("topic"))
					comms.configureReceiver(namespace.getName(), namespace.getType(), namespace.getEndpoint(),
							namespace.getSubsriptionName());
				else if (namespace.getType().equals("queue"))
					comms.configureSender(namespace.getName(), namespace.getType(), namespace.getEndpoint());
			}
		}

		// start receiving
		comms.receiveMsg();

	}

}
