package com.cgp.edgeRuntime;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.cgp.ertServices.ErtServices;
import com.cgp.models.EdgeDetails;
import com.cgp.models.NamespaceDetails;
import com.cgp.models.ResponseData;
import com.cgp.serviceBus.AzureComms;

@Component
public class ErtRun implements CommandLineRunner {

	@Autowired
	ErtServices svc;

	@Autowired
	AzureComms comms;

	@Autowired
	ResponseData responseData;

	@Autowired
	ErtConstant constant;
	
	Logger logger =  LoggerFactory.getLogger(ErtRun.class);


	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub

		// Register Device object
		EdgeDetails detail = new EdgeDetails(constant.getEdge_name(), constant.getEdge_location());
		detail.setHostip(constant.getHost_ip());
		ResponseData response = svc.edgeRegistration(detail);
		responseData.setEdge(response.getEdge());
		responseData.setMngment(response.getMngment());
		responseData.setService(response.getService());
		detail = responseData.getEdge();
		logger.info("device registered with id" + detail.getEdge_id());

		// Get Subscription
		List<NamespaceDetails> mngmt_namespace = null;
		mngmt_namespace = responseData.getMngment();
		// configure azure comms object
		if (mngmt_namespace != null) {
			for (NamespaceDetails namespace : mngmt_namespace) {
				if (namespace.getType().equals("topic"))
					comms.configureReceiver(namespace.getName(), namespace.getType(), namespace.getEndpoint(),
							namespace.getSubsriptionName());
				else if (namespace.getType().equals("queue"))
					comms.configureSender(namespace.getName(), namespace.getType(), namespace.getEndpoint());
			}
		}

		// start receiving
		comms.receiveMsg();

	}

}
