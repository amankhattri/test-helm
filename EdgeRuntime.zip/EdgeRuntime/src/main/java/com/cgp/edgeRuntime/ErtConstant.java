package com.cgp.edgeRuntime;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties("ert")
public class ErtConstant {

	private String edge_name;
	private String edge_location;
	private String edm_url;
	private String zone_id;
	private String host_ip;

	public String getEdge_name() {
		return edge_name;
	}

	public void setEdge_name(String edge_name) {
		this.edge_name = edge_name;
	}

	public String getEdge_location() {
		return edge_location;
	}

	public void setEdge_location(String edge_location) {
		this.edge_location = edge_location;
	}

	public String getEdm_url() {
		return edm_url;
	}

	public void setEdm_url(String edm_url) {
		this.edm_url = edm_url;
	}

	public String getZone_id() {
		return zone_id;
	}

	public void setZone_id(String zone_id) {
		this.zone_id = zone_id;
	}

	public String getHost_ip() {
		return host_ip;
	}

	public void setHost_ip(String host_ip) {
		this.host_ip = host_ip;
	}

}
