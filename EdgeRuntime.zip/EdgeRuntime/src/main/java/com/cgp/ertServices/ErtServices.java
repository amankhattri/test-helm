package com.cgp.ertServices;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.cgp.edgeRuntime.ErtConstant;
import com.cgp.models.EdgeDetails;
import com.cgp.models.ResponseData;

@Component
public class ErtServices {

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	ErtConstant constant;

	Logger logger = LoggerFactory.getLogger(ErtServices.class);

	public ResponseData edgeRegistration(EdgeDetails details) {
		try {

			String url = constant.getEdm_url() + "register";
			ResponseEntity<ResponseData> response = restTemplate.postForEntity(url, details, ResponseData.class);
			if (response.getStatusCode().equals(HttpStatus.CREATED)) {
				logger.info("device registerd succesfully... ");
			} else if (response.getStatusCode().equals(HttpStatus.OK)) {
				logger.info("device was already registerd  ");
			} else {
				logger.error(response.getBody().toString());
				return null;
			}
			return response.getBody();
		} catch (Exception e) {
			logger.error("error in edge Registration : " + e.getMessage());
			return null;
			// TODO: handle exception
		}

	}
}