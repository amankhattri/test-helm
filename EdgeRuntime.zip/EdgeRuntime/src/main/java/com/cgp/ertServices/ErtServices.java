package com.cgp.ertServices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.cgp.models.DeviceDetails;
import com.cgp.models.ResponseData;

@Component
public class ErtServices {

	@Autowired
	RestTemplate restTemplate;

	@Value("${edm.url}")
	String edmUrl;

	public ResponseData DeviceRegistration(DeviceDetails details) {
		String url = edmUrl + "register";
		ResponseEntity<ResponseData> response = restTemplate.postForEntity(url, details, ResponseData.class);
		if (response.getStatusCode().equals(HttpStatus.CREATED)) {
			System.out.println("device registerd succesfully... ");
		} else if (response.getStatusCode().equals(HttpStatus.OK)) {
			System.out.println("device was already registerd  ");
		} else {
			System.out.println(response.getBody());
			return null;
		}
		return response.getBody();
	}


}
