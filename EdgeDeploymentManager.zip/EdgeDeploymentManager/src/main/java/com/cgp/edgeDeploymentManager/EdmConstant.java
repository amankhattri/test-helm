package com.cgp.edgeDeploymentManager;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties("edm")
public class EdmConstant {

	private String zone_id;
	private String servicebus_endpoints;
	private String mgmt_topic_name = "mgmnt_topic";
	private String mgmt_queue_name = "mgmnt_queue";
	private String service_topic_name = "service_topic";
	private String service_queue_name = "service_queue";

	// Edge deployment status
	private String registerd = "Registerd";
	private String deployed = "deployed";
	private String deploying = "deploying";
	private String terminating = "terminating";
	private String error = "error";
	
	//proxyFteg
	private String proxy_fteg_ip;
	private String proxy_fteg_port;
	
	
	//helm_detail 	
	private String helm_origins;
	private String helm_chart_repo ;
	private String helm_chart_repourl ;
	private String helm_chart_name ;
	
	public String getZone_id() {
		return zone_id;
	}

	public void setZone_id(String zone_id) {
		this.zone_id = zone_id;
	}

	public String getServicebus_endpoints() {
		return servicebus_endpoints;
	}

	public void setServicebus_endpoints(String servicebus_endpoints) {
		this.servicebus_endpoints = servicebus_endpoints;
	}

	public String getMgmt_topic_name() {
		return mgmt_topic_name+"_"+zone_id;
	}


	public String getMgmt_queue_name() {
		return mgmt_queue_name+"_"+zone_id;
	}


	public String getService_topic_name() {
		return service_topic_name+"_"+zone_id;
	}


	public String getService_queue_name() {
		return service_queue_name+"_"+zone_id;
	}

	public String getRegisterd() {
		return registerd;
	}

	public String getDeployed() {
		return deployed;
	}

	public String getDeploying() {
		return deploying;
	}

	public String getTerminating() {
		return terminating;
	}

	public String getError() {
		return error;
	}

	public String getProxy_fteg_ip() {
		return proxy_fteg_ip;
	}

	public void setProxy_fteg_ip(String proxy_fteg_ip) {
		this.proxy_fteg_ip = proxy_fteg_ip;
	}

	public String getProxy_fteg_port() {
		return proxy_fteg_port;
	}

	public void setProxy_fteg_port(String proxy_fteg_port) {
		this.proxy_fteg_port = proxy_fteg_port;
	}

	public String getHelm_origins() {
		return helm_origins;
	}

	public void setHelm_origins(String helm_origins) {
		this.helm_origins = helm_origins;
	}

	public String getHelm_chart_repo() {
		return helm_chart_repo;
	}

	public String getHelm_chart_repourl() {
		return helm_chart_repourl;
	}

	public String getHelm_chart_name() {
		return helm_chart_name;
	}

	public void setHelm_chart_repo(String helm_chart_repo) {
		this.helm_chart_repo = helm_chart_repo;
	}

	public void setHelm_chart_repourl(String helm_chart_repourl) {
		this.helm_chart_repourl = helm_chart_repourl;
	}

	public void setHelm_chart_name(String helm_chart_name) {
		this.helm_chart_name = helm_chart_name;
	}

	

}
