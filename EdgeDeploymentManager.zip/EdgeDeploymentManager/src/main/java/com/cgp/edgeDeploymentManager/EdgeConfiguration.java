package com.cgp.edgeDeploymentManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.azure.messaging.servicebus.administration.models.QueueProperties;
import com.azure.messaging.servicebus.administration.models.TopicProperties;
import com.cgp.models.NamespaceDetails;
import com.cgp.repositories.NamespaceDetailsRepository;
import com.cgp.serviceBus.AzureComms;
import com.cgp.serviceBus.AzureCommsImpl;
import com.cgp.serviceBus.CreateNamespaces;

@Configuration
public class EdgeConfiguration {

	@Value("${servicebus.connection}")
	String connection_string;

	@Value("${edm.zoneId}")
	String zoneId;

	public static String MgmtTopicName = "mgmnt_topic_";
	public static String MgmtQueueName = "mgmnt_queue_";

	public static String ServiceTopicName = "service_topic_";
	public static String ServiceQueueName = "service_queue_";

	@Autowired
	NamespaceDetailsRepository namespace_repo;

	@Bean
	public CreateNamespaces createNamespace() {

		TopicProperties tProp;
		QueueProperties qProp;
		String sbNamespace = connection_string.substring(14, connection_string.indexOf('.'));
		CreateNamespaces ns = new CreateNamespaces(connection_string);

		System.out.println("EDM running in zone : " + zoneId);
		tProp = ns.createTopic(MgmtTopicName + zoneId);
		storeNamespace(tProp, "management", sbNamespace);

		qProp = ns.createQueue(MgmtQueueName + zoneId);
		storeNamespace(qProp, "management", sbNamespace);

		tProp = ns.createTopic(ServiceTopicName + zoneId);
		storeNamespace(tProp, "service", sbNamespace);

		qProp = ns.createQueue(ServiceQueueName + zoneId);
		storeNamespace(qProp, "service", sbNamespace);

		return ns;
	}

	@Bean
	public AzureComms azurecomms() {
		AzureComms comms = new AzureCommsImpl();
		comms.configureSender(MgmtTopicName+zoneId, "topic", connection_string);
		comms.configureReceiver(MgmtQueueName+zoneId, "queue", connection_string);				
		comms.receiveMsg();
		return comms;

	}

	private void storeNamespace(Object obj, String mType, String cnName) {
		if (obj instanceof TopicProperties) {
			TopicProperties topic = (TopicProperties) obj;
			NamespaceDetails detail = new NamespaceDetails();
			detail.setName(topic.getName());
			detail.setType("topic");
			detail.setMtype(mType);
			detail.setEndpoint(connection_string);
			namespace_repo.save(detail);

		} else if (obj instanceof QueueProperties) {
			QueueProperties queue = (QueueProperties) obj;
			NamespaceDetails detail = new NamespaceDetails();
			detail.setName(queue.getName());
			detail.setType("queue");
			detail.setMtype(mType);
			detail.setEndpoint("Endpoint=sb://" + cnName + ".servicebus.windows.net/;" + "SharedAccessKeyName="
					+ queue.getAuthorizationRules().get(0).getKeyName() + ";" + "SharedAccessKey="
					+ queue.getAuthorizationRules().get(0).getSecondaryKey() + ";" + "EntityPath="
					+ queue.getName().toLowerCase() + "");
			namespace_repo.save(detail);
		} else
			System.out.println();
	}
}
