package com.cgp.edgeDeploymentManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.azure.messaging.servicebus.administration.models.QueueProperties;
import com.azure.messaging.servicebus.administration.models.TopicProperties;
import com.cgp.models.NamespaceDetails;
import com.cgp.repositories.NamespaceDetailsRepository;
import com.cgp.serviceBus.AzureComms;
import com.cgp.serviceBus.AzureCommsImpl;
import com.cgp.serviceBus.CreateNamespaces;

@Configuration
public class EdgeConfiguration {

	@Autowired
	NamespaceDetailsRepository namespace_repo;
	
	@Autowired
	EdmConstant constant;
	
	Logger logger =  LoggerFactory.getLogger(EdgeConfiguration.class);

	@Bean
	public CreateNamespaces createNamespace() {

		TopicProperties tProp;
		QueueProperties qProp;
		
		String connection_string = constant.getServicebus_endpoints();
		String sbNamespace = connection_string.substring(14, connection_string.indexOf('.'));
		CreateNamespaces ns = new CreateNamespaces(connection_string);

		logger.info("EDM running in zone : " + constant.getZone_id());
		
		tProp = ns.createTopic(constant.getMgmt_topic_name());
		storeNamespace(tProp, "management", sbNamespace);

		qProp = ns.createQueue(constant.getMgmt_queue_name());
		storeNamespace(qProp, "management", sbNamespace);

		tProp = ns.createTopic(constant.getService_topic_name());
		storeNamespace(tProp, "service", sbNamespace);

		qProp = ns.createQueue(constant.getService_queue_name());
		storeNamespace(qProp, "service", sbNamespace);

		return ns;
	}

	@Bean
	public AzureComms azurecomms() {
		AzureComms comms = new AzureCommsImpl();
		comms.configureSender(constant.getMgmt_topic_name(), "topic",constant.getServicebus_endpoints() );
		comms.configureReceiver(constant.getMgmt_queue_name(), "queue", constant.getServicebus_endpoints());				
		comms.receiveMsg();
		return comms;

	}

	private void storeNamespace(Object obj, String mType, String cnName) {
		if (obj instanceof TopicProperties) {
			TopicProperties topic = (TopicProperties) obj;
			NamespaceDetails detail = new NamespaceDetails();
			detail.setName(topic.getName());
			detail.setType("topic");
			detail.setMtype(mType);
			detail.setEndpoint(constant.getServicebus_endpoints());
			namespace_repo.save(detail);

		} else if (obj instanceof QueueProperties) {
			QueueProperties queue = (QueueProperties) obj;
			NamespaceDetails detail = new NamespaceDetails();
			detail.setName(queue.getName());
			detail.setType("queue");
			detail.setMtype(mType);
			detail.setEndpoint("Endpoint=sb://" + cnName + ".servicebus.windows.net/;" + "SharedAccessKeyName="
					+ queue.getAuthorizationRules().get(0).getKeyName() + ";" + "SharedAccessKey="
					+ queue.getAuthorizationRules().get(0).getSecondaryKey() + ";" + "EntityPath="
					+ queue.getName().toLowerCase() + "");
			namespace_repo.save(detail);
		} else
			System.out.println();
	}
}
