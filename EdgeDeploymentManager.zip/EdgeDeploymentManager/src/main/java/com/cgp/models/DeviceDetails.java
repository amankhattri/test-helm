package com.cgp.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import java.util.List;

@Document(collection = "DeviceDetails")
public class DeviceDetails {

	@Id
	private String device_id;

	@Field("device_name")
	private String name;
	private String location;
	
	private String status;
	
	private List<PodStatus> poddetails;
    
	private String hostip;
	
	public DeviceDetails() {
	}

	public String getDevice_id() {
		return device_id;
	}

	public void setDevice_id(String device_id) {
		this.device_id = device_id;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}


	public String getDevice_name() {
		return name;
	}

	public void setDevice_name(String device_name) {
		this.name = device_name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<PodStatus> getPoddetails() {
		return poddetails;
	}

	public void setPoddetails(List<PodStatus> poddetails) {
		this.poddetails = poddetails;
	}

	public String getHostip() {
		return hostip;
	}

	public void setHostip(String hostip) {
		this.hostip = hostip;
	}

}
