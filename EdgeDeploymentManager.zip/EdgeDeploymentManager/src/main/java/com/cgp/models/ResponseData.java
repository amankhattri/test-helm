package com.cgp.models;

import java.util.List;

public class ResponseData {

	private EdgeDetails edge;
	private List<NamespaceDetails> Mngment;
	private List<NamespaceDetails> Service;

	public EdgeDetails getEdge() {
		return edge;
	}

	public void setEdge(EdgeDetails edge) {
		this.edge = edge;
	}

	public List<NamespaceDetails> getMngment() {
		return Mngment;
	}

	public void setMngment(List<NamespaceDetails> mngment) {
		Mngment = mngment;
	}

	public List<NamespaceDetails> getService() {
		return Service;
	}

	public void setService(List<NamespaceDetails> service) {
		Service = service;
	}

}
