package com.cgp.models;

public class ProxyFtegDetails {

	private String AccessIP;
	private String AccessPort;

	public String getAccessIP() {
		return AccessIP;
	}

	public void setAccessIP(String accessIP) {
		AccessIP = accessIP;
	}

	public String getAccessPort() {
		return AccessPort;
	}

	public void setAccessPort(String accessPort) {
		AccessPort = accessPort;
	}

}
