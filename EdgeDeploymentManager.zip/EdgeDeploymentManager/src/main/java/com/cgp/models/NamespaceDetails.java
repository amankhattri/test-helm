package com.cgp.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Document(collection = "NamespaceDetails")
public class NamespaceDetails {

   @Id
    private String name;
    private String type;
    private String endpoint;
    private String mtype;
    
    @Transient
    @JsonInclude(Include.NON_NULL)
    private String subsriptionName;
    
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getEndpoint() {
		return endpoint;
	}
	public void setEndpoint(String endpoint) {
		this.endpoint = endpoint;
	}
	public String getMtype() {
		return mtype;
	}
	public void setMtype(String mtype) {
		this.mtype = mtype;
	}
	public String getSubsriptionName() {
		return subsriptionName;
	}
	public void setSubsriptionName(String subsriptionName) {
		this.subsriptionName = subsriptionName;
	}

	
    
	
}
