package com.cgp.models;

import java.util.ArrayList;
import java.util.List;

public class PodStatus {

	private String name;
	private String status;
	private String message;
	private List<String> podIP;
	
	public PodStatus()
	{
		this.podIP = new ArrayList<>(); 
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<String> getPodIP() {
		return podIP;
	}

/*	public void setPodIP(List<String> podIP) {
		this.podIP = podIP;
	}
*/
}
