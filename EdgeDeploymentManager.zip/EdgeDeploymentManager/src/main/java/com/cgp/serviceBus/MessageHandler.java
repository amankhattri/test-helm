package com.cgp.serviceBus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.azure.messaging.servicebus.ServiceBusReceivedMessage;
import com.cgp.edmServices.EdmService;
import com.cgp.models.Message;

@Component
public class MessageHandler {

	@Autowired
	AzureComms comms;

	@Autowired
	EdmService edmService;

	public void processMessage(ServiceBusReceivedMessage message) {
		String msgId = message.getCorrelationId();
		Message responseMsg = message.getBody().toObject(Message.class);

		System.out.println(responseMsg.toString());
		String type = responseMsg.getType();

		switch (type) {
		case "DeploymentRes":
			edmService.deployFtegRes(responseMsg);
		default:
			System.out.println("in default");
		}

	}

}
