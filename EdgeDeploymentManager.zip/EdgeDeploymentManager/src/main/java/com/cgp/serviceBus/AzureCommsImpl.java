package com.cgp.serviceBus;

import org.springframework.beans.factory.annotation.Autowired;

import com.azure.core.util.BinaryData;
import com.azure.messaging.servicebus.ServiceBusClientBuilder;
import com.azure.messaging.servicebus.ServiceBusMessage;
import com.azure.messaging.servicebus.ServiceBusReceiverAsyncClient;
import com.azure.messaging.servicebus.ServiceBusSenderAsyncClient;
import com.cgp.models.Message;



public class AzureCommsImpl implements AzureComms {

	@Autowired
	MessageHandler handler;
	
	private ServiceBusSenderAsyncClient sender;
	private ServiceBusReceiverAsyncClient receiver;

	public AzureCommsImpl() {
		super();
	}

	@Override
	public String configureSender(String name, String entityType, String endpoints) {

		String res = "SUCCESS";
		if (entityType.equalsIgnoreCase("topic"))
			sender = new ServiceBusClientBuilder().connectionString(endpoints).sender().topicName(name)
					.buildAsyncClient();
		else if (entityType.equalsIgnoreCase("queue"))
			sender = new ServiceBusClientBuilder().connectionString(endpoints).sender().queueName(name)
					.buildAsyncClient();
		else
			return "FAILURE, entityType must be topic or queue ";

		return res;
	}

	@Override
	public String configureReceiver(String name, String entityType, String endpoints) {

		String res = "SUCCESS";
		if (entityType.equalsIgnoreCase("topic"))
			receiver = new ServiceBusClientBuilder().connectionString(endpoints).receiver().topicName(name)
					.buildAsyncClient();
		else if (entityType.equalsIgnoreCase("queue"))
			receiver = new ServiceBusClientBuilder().connectionString(endpoints).receiver().queueName(name)
					.buildAsyncClient();
		else
			return "FAILURE, entityType must be topic or queue ";

		return res;
	}

	@Override
	public String configureReceiver(String name, String entityType, String endpoints, String subscription) {

		String res = "SUCCESS";
		if (entityType.equalsIgnoreCase("topic"))
			receiver = new ServiceBusClientBuilder().connectionString(endpoints).receiver().topicName(name)
					.subscriptionName(subscription).buildAsyncClient();
		else if (entityType.equalsIgnoreCase("queue"))
			receiver = new ServiceBusClientBuilder().connectionString(endpoints).receiver().queueName(name)
					.buildAsyncClient();
		else
			return "FAILURE, entityType must be topic or queue ";

		return res;
	}

	@Override
	public String sendMsg(Message data) {
		if (sender == null)
			return "Failure, sender not configure";
		
		ServiceBusMessage msg = new ServiceBusMessage(BinaryData.fromObject(data));
		msg.setCorrelationId("config-app-"+data.getId());
		//msg.setSubject(data.getId());
		
		sender.sendMessage(msg).subscribe(unused -> System.out.println("sent.."),
				error -> System.err.println("Error in publishing message" + error),
				() -> System.out.println("send successfull"));
		return "";
	}

	@Override
	public String receiveMsg()

	{
		if (receiver == null)
			return "Failure, sender not configure";
		receiver.receiveMessages().subscribe(message -> {
			//System.out.println("recieved msg : " + message.getBody());
			handler.processMessage(message);
		}, error -> {
			System.out.println("error while receiving messaage" + error);
		}, () -> System.out.println("receive complete"));
		return "";
	}

}
