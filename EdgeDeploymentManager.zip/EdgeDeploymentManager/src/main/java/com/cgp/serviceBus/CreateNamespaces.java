package com.cgp.serviceBus;

import java.util.ArrayList;
import java.util.List;

import com.azure.core.exception.ResourceNotFoundException;
import com.azure.core.http.policy.HttpLogDetailLevel;
import com.azure.core.http.policy.HttpLogOptions;
import com.azure.messaging.servicebus.administration.ServiceBusAdministrationClient;
import com.azure.messaging.servicebus.administration.ServiceBusAdministrationClientBuilder;
import com.azure.messaging.servicebus.administration.models.AccessRights;
import com.azure.messaging.servicebus.administration.models.CorrelationRuleFilter;
import com.azure.messaging.servicebus.administration.models.CreateQueueOptions;
import com.azure.messaging.servicebus.administration.models.CreateRuleOptions;
import com.azure.messaging.servicebus.administration.models.CreateSubscriptionOptions;
import com.azure.messaging.servicebus.administration.models.CreateTopicOptions;
import com.azure.messaging.servicebus.administration.models.QueueProperties;
import com.azure.messaging.servicebus.administration.models.RuleAction;
import com.azure.messaging.servicebus.administration.models.RuleProperties;
import com.azure.messaging.servicebus.administration.models.SharedAccessAuthorizationRule;
import com.azure.messaging.servicebus.administration.models.SubscriptionProperties;
import com.azure.messaging.servicebus.administration.models.TopicProperties;
import com.azure.messaging.servicebus.implementation.models.RuleActionImpl;

public class CreateNamespaces {

	private String connection_string;
	// private String queue_name;
	// private String topic_name;
	private ServiceBusAdministrationClient client;

	public CreateNamespaces(String connection_string) {
		this.connection_string = connection_string;
		HttpLogOptions logOptions = new HttpLogOptions().setLogLevel(HttpLogDetailLevel.HEADERS);
		client = new ServiceBusAdministrationClientBuilder().connectionString(this.connection_string)
				.httpLogOptions(logOptions).buildClient();
	}

//create topic
	public TopicProperties createTopic(String topicName) {

		TopicProperties topic = null;

		topic = getTopic(topicName);
		if (topic != null)
			return topic;

		List<AccessRights> access = new ArrayList<>();
		access.add(AccessRights.LISTEN);
		access.add(AccessRights.SEND);
		SharedAccessAuthorizationRule topic_rule = new SharedAccessAuthorizationRule("topicKey", access);

		List<SharedAccessAuthorizationRule> rt = new ArrayList<>();
		rt.add(topic_rule);

		CreateTopicOptions cto = new CreateTopicOptions();
		cto.getAuthorizationRules().add(topic_rule);
		cto.setMaxSizeInMegabytes(1024);

		topic = client.createTopic(topicName, cto);
		System.out.println("topic ::\n" + "MaxSizeInBytes " + topic.getMaxSizeInMegabytes() + "\nName "
				+ topic.getName() + "\nUserMetadata " + topic.getUserMetadata() + "\nAuthorizationRules "
				+ topic.getAuthorizationRules().toString() + "\nAutoDeleteOnIdle " + topic.getAutoDeleteOnIdle()
				+ "\nDefaultMessageTimeTOLive " + topic.getDefaultMessageTimeToLive()
				+ "\nDuplicateDetectionHistoryTimeWindow " + topic.getDuplicateDetectionHistoryTimeWindow()
				+ "\nStatus  " + topic.getStatus());
		return topic;
	}

//create Queue	

	public QueueProperties createQueue(String queueName) {

		QueueProperties queue = null;
		queue = getQueue(queueName);
		if (queue != null)
			return queue;
		List<AccessRights> access = new ArrayList<>();
		access.add(AccessRights.LISTEN);
		access.add(AccessRights.SEND);
		SharedAccessAuthorizationRule queue_rule = new SharedAccessAuthorizationRule("queueKey", access);
		CreateQueueOptions cqo = new CreateQueueOptions();
		cqo.getAuthorizationRules().add(queue_rule);
		cqo.setMaxSizeInMegabytes(1024);

		queue = client.createQueue(queueName, cqo);
		System.out.println("topic ::\n" + "MaxSizeInBytes " + queue.getMaxSizeInMegabytes() + "\nName "
				+ queue.getName() + "\nUserMetadata " + queue.getUserMetadata() + "\nAuthorizationRules "
				+ queue.getAuthorizationRules().toString() + "\nAutoDeleteOnIdle " + queue.getAutoDeleteOnIdle()
				+ "\nDefaultMessageTimeTOLive " + queue.getDefaultMessageTimeToLive()
				+ "\nDuplicateDetectionHistoryTimeWindow " + queue.getDuplicateDetectionHistoryTimeWindow()
				+ "\nStatus  " + queue.getStatus());
		return queue;

	}

	public QueueProperties getQueue(String queue) {
		QueueProperties response = null;
		try {
			response = client.getQueue(queue);
		} catch (ResourceNotFoundException e) {
			return response;
		}
		return response;

	}

	public TopicProperties getTopic(String topic) {
		TopicProperties response = null;
		try {
			response = client.getTopic(topic);
		} catch (ResourceNotFoundException e) {
			return response;
		}

		return response;

	}

	public String CreateSubscription(String TopicName, String SubscriptionName) {

		CreateSubscriptionOptions cso = new CreateSubscriptionOptions();
		cso.setEnableDeadLetteringOnFilterEvaluationExceptions(false);
		SubscriptionProperties subs = client.createSubscription(TopicName, SubscriptionName, cso);
		client.deleteRule(TopicName, SubscriptionName, "$Default");

		CreateRuleOptions cro = new CreateRuleOptions();
		// cro.setFilter(new
		// CorrelationRuleFilter(SubscriptionName).setCorrelationId(SubscriptionName)
		// .setLabel(SubscriptionName));
		cro.setFilter(new CorrelationRuleFilter(SubscriptionName).setCorrelationId("config-app-" + SubscriptionName));
		RuleProperties rule = client.createRule(TopicName, "rule_fteg", SubscriptionName, cro);

		return subs.getSubscriptionName();
	}

	public void deleteSubscription(String TopicName, String SubscriptionName) {

		client.deleteSubscription(TopicName, SubscriptionName);

		// return subs.getSubscriptionName();
	}

	public void delete() {
		client.deleteQueue("testQ");
		client.deleteTopic("testT");
	}

}
