package com.cgp.edmServices;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cgp.models.EdgeDetails;
import com.cgp.models.NamespaceDetails;
import com.cgp.repositories.EdgeDetailsRepository;
import com.cgp.repositories.NamespaceDetailsRepository;
import com.cgp.serviceBus.CreateNamespaces;

@Service
public class EdgeServiceImp implements EdgeServices {

	@Autowired
	EdgeDetailsRepository edgeDetailRepositroy;

	@Autowired
	NamespaceDetailsRepository namespaceDetailRepository;

	@Autowired
	CreateNamespaces createNamespace;

	Logger logger = LoggerFactory.getLogger(EdgeServiceImp.class);

	@Override
	public EdgeDetails edgeRegistration(EdgeDetails details) {
		// TODO Auto-generated method stub
		return edgeDetailRepositroy.save(details);

	}

	@Override
	public EdgeDetails getEdgeById(String id) {
		// TODO Auto-generated method stub
		EdgeDetails EdgeDetails = null;
		try {
			EdgeDetails = edgeDetailRepositroy.findById(id).orElseThrow(() -> new Exception());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			logger.info(" error while getting device detail with id"+ id + "\n error: "+e.getMessage());
		}
		return EdgeDetails;
	}

	@Override
	public List<NamespaceDetails> getNamespaceInfo(String mtype) {
		// TODO Auto-generated method stub
		return namespaceDetailRepository.findByMtype(mtype);
	}

	@Override
	public String createSubscription(String TopicName, String id) {
		return createNamespace.CreateSubscription(TopicName, id);

	}

	@Override
	public EdgeDetails getEdgeByName(String name) {
		// TODO Auto-generated method stub
		return edgeDetailRepositroy.findByName(name);
	}

	@Override
	public List<EdgeDetails> getAllDevices() {
		// TODO Auto-generated method stub
		return edgeDetailRepositroy.findAll();
	}

	@Override
	public void removeDeviceById(String id) {
		// TODO Auto-generated method stub

		edgeDetailRepositroy.deleteById(id);
		// return null;
	}

	@Override
	public void deleteSubscription(String TopicName, String id) {
		createNamespace.deleteSubscription(TopicName, id);
	}
}
