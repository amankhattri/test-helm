package com.cgp.edmServices;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cgp.models.DeviceDetails;
import com.cgp.models.NamespaceDetails;
import com.cgp.repositories.DeviceDetailsRepository;
import com.cgp.repositories.NamespaceDetailsRepository;
import com.cgp.serviceBus.CreateNamespaces;

@Service
public class EdgeServiceImp implements EdgeServices {

	@Autowired
	DeviceDetailsRepository deviceDetailRepositroy;

	@Autowired
	NamespaceDetailsRepository namespaceDetailRepository;

	@Autowired
	CreateNamespaces createNamespace;

	@Override
	public DeviceDetails deviceRegistration(DeviceDetails details) {
		// TODO Auto-generated method stub
		return deviceDetailRepositroy.save(details);

	}

	@Override
	public DeviceDetails getDeviceById(String id) {
		// TODO Auto-generated method stub
		DeviceDetails deviceDetails = null;
		try {
			deviceDetails = deviceDetailRepositroy.findById(id).orElseThrow(() -> new Exception());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return deviceDetails;
	}

	@Override
	public List<NamespaceDetails> getNamespaceInfo(String mtype) {
		// TODO Auto-generated method stub
		return namespaceDetailRepository.findByMtype(mtype);
	}

	@Override
	public String createSubscription(String TopicName,String id) {
     return createNamespace.CreateSubscription(TopicName, id);
		
	}

	@Override
	public DeviceDetails getDeviceByName(String name) {
		// TODO Auto-generated method stub
		return  deviceDetailRepositroy.findByName(name);
	}

	@Override
	public List<DeviceDetails> getAllDevices() {
		// TODO Auto-generated method stub
		return deviceDetailRepositroy.findAll();
	}

	@Override
	public void removeDeviceById(String id) {
		// TODO Auto-generated method stub
		
		deviceDetailRepositroy.deleteById(id);
		//return null;
	}

	  @Override
	  public void deleteSubscription(String TopicName,String id)
	  {
		  createNamespace.deleteSubscription(TopicName, id);
	  }
}
