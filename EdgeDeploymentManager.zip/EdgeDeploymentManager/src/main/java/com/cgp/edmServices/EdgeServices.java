package com.cgp.edmServices;

import java.util.List;

import com.cgp.models.EdgeDetails;
import com.cgp.models.NamespaceDetails;

public interface EdgeServices {

	public EdgeDetails edgeRegistration(EdgeDetails details); 
	public EdgeDetails getEdgeById(String id);
	public EdgeDetails getEdgeByName(String name);
    public List<NamespaceDetails> getNamespaceInfo(String mType);
    public String createSubscription(String TopicName,String id);
	public List<EdgeDetails> getAllDevices();
	public void removeDeviceById(String id);
    public void deleteSubscription(String TopicName,String id);

    
	
	
}
