package com.cgp.edmServices;

import java.util.List;

import com.cgp.models.DeviceDetails;
import com.cgp.models.NamespaceDetails;

public interface EdgeServices {

	public DeviceDetails deviceRegistration(DeviceDetails details); 
	public DeviceDetails getDeviceById(String id);
	public DeviceDetails getDeviceByName(String name);
    public List<NamespaceDetails> getNamespaceInfo(String mType);
    public String createSubscription(String TopicName,String id);
	public List<DeviceDetails> getAllDevices();
	public void removeDeviceById(String id);
    public void deleteSubscription(String TopicName,String id);

    
	
	
}
