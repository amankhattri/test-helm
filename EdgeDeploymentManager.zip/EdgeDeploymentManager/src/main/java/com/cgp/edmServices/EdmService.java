package com.cgp.edmServices;

import com.cgp.models.HelmDeploymentDetail;
import com.cgp.models.Message;

public interface EdmService {

	 public void deployFteg(String deviceID, HelmDeploymentDetail helm_detail);
	 public void deployFtegRes(Message responseMsg);
	 public void unDeployFteg(String device_id, HelmDeploymentDetail helm_detail);
	public void UnDeployFtegRes(Message responseMsg);
}
