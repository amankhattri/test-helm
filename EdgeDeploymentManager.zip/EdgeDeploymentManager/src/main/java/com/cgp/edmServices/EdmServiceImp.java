package com.cgp.edmServices;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cgp.models.DeviceDetails;
import com.cgp.models.HelmDeploymentDetail;
import com.cgp.models.Message;
import com.cgp.models.PodStatus;
import com.cgp.serviceBus.AzureComms;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import ch.qos.logback.core.subst.Token.Type;

@Service
public class EdmServiceImp implements EdmService {

	@Autowired
	EdgeServices edgeService;

	@Autowired
	AzureComms comms;

	@Override
	public void deployFteg(String deviceID, HelmDeploymentDetail helm_detail) {
		DeviceDetails device;
		if ((device = edgeService.getDeviceById(deviceID)) != null) {
			
			if(device.getStatus().equals("deployed"))
		      return ;
			helm_detail.setHelmId(device.getDevice_name().toLowerCase());
			Gson gson = new Gson();
			Message msg = new Message();
			msg.setId(device.getDevice_id());
			msg.setPayload(gson.toJson(helm_detail));
			msg.setType("DeploymentReq");
			comms.sendMsg(msg);
			device.setStatus("deploying");
			edgeService.deviceRegistration(device);
		}
	}

	@Override
	public void deployFtegRes(Message responseMsg) {
		// TODO Auto-generated method stub
		// if (responseMsg.getPayload().toString().equals("deployed")) {
		if (responseMsg.getStatus().equals("SUCCESS")) {			
			@SuppressWarnings("unchecked")
			//Map<String, PodStatus> podMap = (Map<String, PodStatus>) responseMsg.getPayload();
			
			Gson gson = new Gson();
			java.lang.reflect.Type podMapType = new TypeToken<Map<String, PodStatus>>() {}.getType();
			Map<String, PodStatus> podMap = gson.fromJson(responseMsg.getPayload().toString(),podMapType);			
            List<PodStatus> pods = new ArrayList<PodStatus>() ;
			podMap.forEach((k,v)->{
				pods.add(v);
			});
			DeviceDetails device;
			device = edgeService.getDeviceById(responseMsg.getId().replace("config-app-", ""));
			device.setPoddetails(pods);
			device.setStatus("deployed");
			edgeService.deviceRegistration(device);
		}
	}

}
