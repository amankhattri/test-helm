package com.cgp.edmServices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cgp.edgeDeploymentManager.EdmConstant;
import com.cgp.models.EdgeDetails;
import com.cgp.models.HelmDeploymentDetail;
import com.cgp.models.Message;
import com.cgp.models.PodStatus;
import com.cgp.serviceBus.AzureComms;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

@Service
public class EdmServiceImp implements EdmService {

	@Autowired
	EdgeServices edgeService;

	@Autowired
	AzureComms comms;

	@Autowired
	EdmConstant constant;
	
	
	Logger logger = LoggerFactory.getLogger(EdmServiceImp.class);

	@Override
	public void deployFteg(String deviceID, HelmDeploymentDetail helm_detail) {
		EdgeDetails device;
		if ((device = edgeService.getEdgeById(deviceID)) != null) {

			if (device.getStatus().equals(constant.getDeployed()))
			{  logger.info("Already Deployed");
				return;}
			helm_detail.setHelmId(device.getEdge_name().toLowerCase());
			Map<String, String> extra_params = new HashMap<>();
			extra_params.put("service.fteg_ct.externalIP", device.getHostip());
			helm_detail.setExtraParameters(extra_params);
			Gson gson = new Gson();
			Message msg = new Message();
			msg.setId(device.getEdge_id());
			msg.setPayload(gson.toJson(helm_detail));
			msg.setType("DeploymentReq");
			comms.sendMsg(msg);
			device.setStatus(constant.getDeploying());
			edgeService.edgeRegistration(device);
			 logger.info("send data to azure bus for deploy");
		}
	}

	@Override
	public void deployFtegRes(Message responseMsg) {
		// TODO Auto-generated method stub
		// if (responseMsg.getPayload().toString().equals("deployed")) {
		if (responseMsg.getStatus().equals("SUCCESS")) {
			logger.info("Get fteg deployment response with Success msg");
			@SuppressWarnings("unchecked")
			// Map<String, PodStatus> podMap = (Map<String, PodStatus>)
			// responseMsg.getPayload();

			Gson gson = new Gson();
			java.lang.reflect.Type podMapType = new TypeToken<Map<String, PodStatus>>() {
			}.getType();
			Map<String, PodStatus> podMap = gson.fromJson(responseMsg.getPayload().toString(), podMapType);
			List<PodStatus> pods = new ArrayList<PodStatus>();
			podMap.forEach((k, v) -> {
				pods.add(v);
			});
			EdgeDetails device;
			device = edgeService.getEdgeById(responseMsg.getId().replace("config-app-", ""));
			device.setPoddetails(pods);
			device.setStatus(constant.getDeployed());
			edgeService.edgeRegistration(device);
		} else {
			logger.info("Get fteg deployment response with Error msg");
			EdgeDetails device;
			device = edgeService.getEdgeById(responseMsg.getId().replace("config-app-", ""));
			device.setStatus(constant.getError());
			edgeService.edgeRegistration(device);
		}
	}

	@Override
	public void unDeployFteg(String device_id, HelmDeploymentDetail helm_detail) {
		// TODO Auto-generated method stub
		EdgeDetails device;
		if ((device = edgeService.getEdgeById(device_id)) != null) // && device.getStatus().equals("deployed"))
		{
			if (device.getStatus().equals(constant.getRegisterd()))
			{	logger.info(" Device "+ device_id +" is not deployed");
				return; }
			helm_detail.setHelmId(device.getEdge_name().toLowerCase());
			Gson gson = new Gson();
			Message msg = new Message();
			msg.setId(device.getEdge_id());
			msg.setPayload(gson.toJson(helm_detail));
			msg.setType("UnDeploymentReq");
			comms.sendMsg(msg);
			device.setStatus(constant.getTerminating());
			edgeService.edgeRegistration(device);
			 logger.info("send  data to azure bus for undeploy");

		}
	}

	@Override
	public void UnDeployFtegRes(Message responseMsg) {
		// TODO Auto-generated method stub
		if (responseMsg.getStatus().equals("SUCCESS")) {
			logger.info("Get fteg undeployment response with Success msg");
			EdgeDetails device;
			device = edgeService.getEdgeById(responseMsg.getId().replace("config-app-", ""));
			List<PodStatus> status = device.getPoddetails();
			status.clear();
			device.setPoddetails(status);
			device.setStatus(constant.getRegisterd());
			edgeService.edgeRegistration(device);
		} else {
			logger.info("Get fteg undeployment response with Error msg");
			EdgeDetails device;
			device = edgeService.getEdgeById(responseMsg.getId().replace("config-app-", ""));
			device.setStatus(constant.getError());
			edgeService.edgeRegistration(device);
		}
	}

}
