package com.cgp.security;

import java.io.IOException;
import java.io.Serializable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import com.cgp.edmServices.EdmServiceImp;

@Component
public class JwtAuthenticationEntryPoint implements AuthenticationEntryPoint ,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1457104060459545990L;
	
	Logger logger = LoggerFactory.getLogger(JwtAuthenticationEntryPoint.class);


	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException authException) throws IOException, ServletException {
		// TODO Auto-generated method stub
		final String expiredMsg = (String) request.getAttribute("expired");
		final String msg = (expiredMsg != null) ? expiredMsg : "Unauthorized";
		logger.error("Unauthorized Error"+"msg");
		
		response.sendError(HttpServletResponse.SC_UNAUTHORIZED, msg);
	}

}
