package com.cgp.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.cgp.models.DeviceDetails;

public interface DeviceDetailsRepository extends MongoRepository<DeviceDetails, String> {

	DeviceDetails findByName(String device_name);
}
