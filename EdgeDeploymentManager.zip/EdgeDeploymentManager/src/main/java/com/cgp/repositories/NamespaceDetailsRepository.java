package com.cgp.repositories;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.cgp.models.NamespaceDetails;

public interface NamespaceDetailsRepository extends MongoRepository<NamespaceDetails, String> {

	
	List<NamespaceDetails>  findByMtype(String mtype);

}
