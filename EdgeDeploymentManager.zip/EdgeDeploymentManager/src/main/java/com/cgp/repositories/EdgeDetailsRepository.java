package com.cgp.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.cgp.models.EdgeDetails;

public interface EdgeDetailsRepository extends MongoRepository<EdgeDetails, String> {

	EdgeDetails findByName(String edge_name);
}
