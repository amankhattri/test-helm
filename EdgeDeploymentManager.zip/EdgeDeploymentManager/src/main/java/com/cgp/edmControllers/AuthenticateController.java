package com.cgp.edmControllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cgp.models.AuthenticationRequest;
import com.cgp.models.AuthenticationResponse;
import com.cgp.models.JwtValidationData;
import com.cgp.security.JwtUtil;
import com.cgp.security.MyUserDetailsService;

@RestController
public class AuthenticateController {

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private MyUserDetailsService userDetailsService;

	@Autowired
	private JwtUtil jwtutil;

	Logger logger = LoggerFactory.getLogger(AuthenticateController.class);

	@PostMapping("/authenticate")
	public ResponseEntity<?> createAuthenticationToken(@RequestBody AuthenticationRequest authenticationRequest)
			throws Exception {
		logger.info("in authentication");
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
					authenticationRequest.getUsername(), authenticationRequest.getPassword()));
			final UserDetails userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getUsername());
			final String jwt = jwtutil.generateToken(userDetails);
			return new ResponseEntity<>(new AuthenticationResponse(jwt), HttpStatus.OK);
		} catch (BadCredentialsException e) {
			logger.error("Incorrect Username & Password " + e);
			return new ResponseEntity<>("Incorrect Username & Password ", HttpStatus.UNAUTHORIZED);

		}

	}

	@PostMapping("/validateToken")
	public ResponseEntity<?> validateToken(@RequestBody JwtValidationData jwt) throws Exception {
		try {
			logger.info("in token validation");
			boolean status = false;
			String username = jwtutil.getUsernameFromToken(jwt.getJwt());
			UserDetails userDetails = userDetailsService.loadUserByUsername(username);
			status = jwtutil.validateToken(jwt.getJwt(), userDetails);
			if (status) {
				jwt.setStatus("SUCCESS");
				jwt.setMessage("Valid Token");
				return new ResponseEntity<>(jwt, HttpStatus.OK);
			} else {
				jwt.setStatus("ERROR");
				jwt.setMessage("Invalid Token");
				return new ResponseEntity<>(jwt, HttpStatus.UNAUTHORIZED);
			}
		} catch (Exception e) {
			// throw new Exception("Incoreect Username & password");
			// TODO: handle exception
			logger.error("Invalid Token" + e);

			jwt.setStatus("ERROR");
			jwt.setMessage("Invalid Token");
			return new ResponseEntity<>(jwt, HttpStatus.UNAUTHORIZED);

		}

	}

}
