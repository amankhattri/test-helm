package com.cgp.edmControllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.cgp.edgeDeploymentManager.EdgeConfiguration;
import com.cgp.models.DeviceDetails;
import com.cgp.models.NamespaceDetails;
import com.cgp.models.ResponseData;

@RestController
public class EdgeController {

	@Autowired
	com.cgp.edmServices.EdgeServices edgeService;

	@Value("${edm.zoneId}")
	String zoneId;

	@PostMapping("/register")
	public ResponseEntity<?> DeviceRegistration(@RequestBody DeviceDetails details) {
		System.out.println("in register");
		HttpStatus status = HttpStatus.CREATED;
		DeviceDetails device;
		device = edgeService.getDeviceByName(details.getDevice_name());
		if (device == null) {
			status = HttpStatus.OK;
			details.setStatus("registerd");
			device = edgeService.deviceRegistration(details);
			edgeService.createSubscription(EdgeConfiguration.MgmtTopicName + zoneId, device.getDevice_id());
			edgeService.createSubscription(EdgeConfiguration.ServiceTopicName + zoneId, device.getDevice_id());
		}

		List<NamespaceDetails> mngmt = edgeService.getNamespaceInfo("management");
		for (NamespaceDetails ns : mngmt) {
			if (ns.getType().equals("topic"))
				ns.setSubsriptionName(device.getDevice_id());
		}

		List<NamespaceDetails> service = edgeService.getNamespaceInfo("service");
		for (NamespaceDetails ns : service) {
			if (ns.getType().equals("topic"))
				ns.setSubsriptionName(device.getDevice_id());
		}

		ResponseData res = new ResponseData();
		res.setDevice(device);
		res.setMngment(mngmt);
		res.setService(service);

		return new ResponseEntity<>(res, status);
	}

	@GetMapping("/device/{id}")
	public ResponseEntity<?> getDeviceById(@PathVariable String id) {
		DeviceDetails res = edgeService.getDeviceById(id);
		return new ResponseEntity<>(res, HttpStatus.OK);

	}

	@GetMapping("/getAlldevices/")
	public ResponseEntity<?> getAllDevices() {
		List<DeviceDetails> res = edgeService.getAllDevices();
		return new ResponseEntity<>(res, HttpStatus.OK);

	}

	@GetMapping("/namespaceInfo/{mType}")
	public ResponseEntity<?> getNamespaceInfo(@PathVariable String mType) {
		return new ResponseEntity<>(edgeService.getNamespaceInfo(mType), HttpStatus.OK);
	}

	@DeleteMapping("/device/{id}")
	public ResponseEntity<?> removeDevice(@PathVariable String id) {

		edgeService.deleteSubscription(EdgeConfiguration.MgmtTopicName + zoneId, id);
		edgeService.deleteSubscription(EdgeConfiguration.ServiceTopicName + zoneId, id);
		edgeService.removeDeviceById(id);
		return new ResponseEntity<>("SUCCESS", HttpStatus.OK);

	}
}
