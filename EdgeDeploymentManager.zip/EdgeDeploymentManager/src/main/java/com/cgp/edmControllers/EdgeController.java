package com.cgp.edmControllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cgp.edgeDeploymentManager.EdmConstant;
import com.cgp.edmServices.EdgeServices;
import com.cgp.models.EdgeDetails;
import com.cgp.models.NamespaceDetails;
import com.cgp.models.ProxyFtegDetails;
import com.cgp.models.ResponseData;

@RestController
public class EdgeController {

	@Autowired
	EdgeServices edgeService;

	@Autowired
	EdmConstant constant;
	
	Logger logger = LoggerFactory.getLogger(EdgeController.class);

	@PostMapping("/register")
	public ResponseEntity<?> edgeRegistration(@RequestBody EdgeDetails details) {
		logger.info("in register");
		logger.info("Device Detail : name="+  details.getEdge_name() +" location="+details.getLocation());
		HttpStatus status = HttpStatus.CREATED;
		EdgeDetails device;
		device = edgeService.getEdgeByName(details.getEdge_name());
		if (device == null) {
			status = HttpStatus.OK;
			details.setStatus(constant.getRegisterd());
			device = edgeService.edgeRegistration(details);
			edgeService.createSubscription(constant.getMgmt_topic_name(), device.getEdge_id());
			edgeService.createSubscription(constant.getService_topic_name(), device.getEdge_id());
		}

		List<NamespaceDetails> mngmt = edgeService.getNamespaceInfo("management");
		for (NamespaceDetails ns : mngmt) {
			if (ns.getType().equals("topic"))
				ns.setSubsriptionName(device.getEdge_id());
		}

		List<NamespaceDetails> service = edgeService.getNamespaceInfo("service");
		for (NamespaceDetails ns : service) {
			if (ns.getType().equals("topic"))
				ns.setSubsriptionName(device.getEdge_id());
		}

		ResponseData res = new ResponseData();
		res.setEdge(device);
		res.setMngment(mngmt);
		res.setService(service);

		return new ResponseEntity<>(res, status);
	}

	@GetMapping("/device/{id}")
	public ResponseEntity<?> getEdgeById(@PathVariable String id) {
		EdgeDetails res = edgeService.getEdgeById(id);
		return new ResponseEntity<>(res, HttpStatus.OK);

	}

	@GetMapping("/getAlldevices/")
	public ResponseEntity<?> getAllEdges() {
		logger.info("in getAlldevices");
		List<EdgeDetails> res = edgeService.getAllDevices();
		return new ResponseEntity<>(res, HttpStatus.OK);

	}

	@GetMapping("/namespaceInfo/{mType}")
	public ResponseEntity<?> getNamespaceInfo(@PathVariable String mType) {
		logger.info("in namespaceInfo");
		return new ResponseEntity<>(edgeService.getNamespaceInfo(mType), HttpStatus.OK);
	}

	@DeleteMapping("/device/{id}")
	public ResponseEntity<?> removeEdge(@PathVariable String id) {
		logger.info("in delete device");

		edgeService.deleteSubscription(constant.getMgmt_topic_name(), id);
		edgeService.deleteSubscription(constant.getService_topic_name(), id);
		edgeService.removeDeviceById(id);
		return new ResponseEntity<>("SUCCESS", HttpStatus.OK);

	}

	@GetMapping("/proxyFtegDetails")
	public ResponseEntity<?> proxyFtegDetails() {
		logger.info("in ProxyFtegDetails");

		ProxyFtegDetails proxy_details = new ProxyFtegDetails();
		String proxyFtegIp = constant.getProxy_fteg_ip();
		String proxyFtegPort = constant.getProxy_fteg_port();
		String ip = (proxyFtegIp != null && !proxyFtegIp.isEmpty()) ? proxyFtegIp : "127.0.0.1";
		String port = (proxyFtegPort != null && !proxyFtegPort.isEmpty()) ? proxyFtegPort : "50000";
		proxy_details.setAccessIP(ip);
		proxy_details.setAccessPort(port);
		
		logger.info( "ProxyFteg: ip="+ip+" port="+port);
		return new ResponseEntity<>(proxy_details, HttpStatus.OK);
	}
}
