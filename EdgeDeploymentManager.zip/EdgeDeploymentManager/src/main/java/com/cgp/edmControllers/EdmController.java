package com.cgp.edmControllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cgp.edgeDeploymentManager.EdmConstant;
import com.cgp.edmServices.EdmService;
import com.cgp.models.HelmDeploymentDetail;

@RestController
public class EdmController {

	@Autowired
	EdmService edmService;

	@Autowired
	EdmConstant constant;

	Logger logger = LoggerFactory.getLogger(EdmController.class);

	@PutMapping("/deployFteg/{device_id}")
	public void deployFteg(@PathVariable String device_id) {
		logger.info("in deployFteg , device Id:"+device_id);
		HelmDeploymentDetail helm_detail = new HelmDeploymentDetail();
		helm_detail.setHelmId(device_id);
		helm_detail.setHelm_origins(constant.getHelm_origins());
		helm_detail.setChartName(constant.getHelm_chart_name());
		helm_detail.setChartRepoName(constant.getHelm_chart_repo());
		helm_detail.setChartRepoUrl(constant.getHelm_chart_repourl());
		edmService.deployFteg(device_id, helm_detail);
	}

	@PutMapping("/undeployFteg/{device_id}")
	public void UnDeployFteg(@PathVariable String device_id) {
		logger.info("in UndeployFteg , device Id:"+device_id);

		HelmDeploymentDetail helm_detail = new HelmDeploymentDetail();
		helm_detail.setHelmId(device_id);
		helm_detail.setHelm_origins(constant.getHelm_origins());
		helm_detail.setChartName(constant.getHelm_chart_name());
		helm_detail.setChartRepoName(constant.getHelm_chart_repo());
		helm_detail.setChartRepoUrl(constant.getHelm_chart_repourl());
		edmService.unDeployFteg(device_id, helm_detail);
	}

}
