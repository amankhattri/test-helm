package com.cgp.edmControllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cgp.edmServices.EdmService;
import com.cgp.models.HelmDeploymentDetail;

@RestController
public class EdmController {

	@Autowired
	EdmService edmService;
	
	@PutMapping("/deployFteg/{device_id}")
	public void deployFteg(@PathVariable String device_id)
	{
	     
		 HelmDeploymentDetail helm_detail = new HelmDeploymentDetail();
		 helm_detail.setHelmId(device_id);
		 helm_detail.setChartName("stable/mysql");
		 helm_detail.setChartRepoName("stable");		
		 helm_detail.setChartRepoUrl("https://charts.helm.sh/stable");		 
		 edmService.deployFteg(device_id,helm_detail);		 
	}
	
	
	
}
