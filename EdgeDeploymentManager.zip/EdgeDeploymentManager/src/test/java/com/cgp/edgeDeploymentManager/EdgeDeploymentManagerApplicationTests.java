package com.cgp.edgeDeploymentManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdgeDeploymentManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
